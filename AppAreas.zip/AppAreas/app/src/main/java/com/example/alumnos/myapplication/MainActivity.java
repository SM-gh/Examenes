package com.example.alumnos.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.CheckBox;
import android.text.TextUtils;

public class MainActivity extends AppCompatActivity {

    private RadioButton radioButton4;
    private RadioButton radioButton5;
    private RadioButton radioButton6;
    private EditText editText1;
    private EditText editText2;
    private EditText editText3;
    private EditText editText4;
    private TextView textView1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText1 = (EditText) findViewById(R.id.txt_1);
        editText2 = (EditText) findViewById(R.id.txt_2);
        editText3 = (EditText) findViewById(R.id.txt_3);
        editText4 = (EditText) findViewById(R.id.txt_4);
        radioButton4 = (RadioButton) findViewById(R.id.radioButtonCirculo);
        radioButton5 = (RadioButton) findViewById(R.id.radioButtonCuadrado);
        radioButton6 = (RadioButton) findViewById(R.id.radioButtonTriangulo);
        textView1 = (TextView) findViewById(R.id.txt_Resultado);

    }

    public void Area(View view){
        String Val1T = editText1.getText().toString();

        String Val2T = editText2.getText().toString();

        String Val3T = editText3.getText().toString();

        String Val4T = editText4.getText().toString();

        double Val1Int = Double.parseDouble(Val1T);
        double Val2Int = Double.parseDouble(Val2T);
        double Val3Int = Double.parseDouble(Val3T);
        double Val4Int = Double.parseDouble(Val4T);

        double Result = 0;


        if (editText1.length() == 0 || editText2.length() == 0 || editText3.length() == 0 || editText4.length() == 0) {
            textView1.setText("Hacen falta datos, compi");
        } else {
            if (radioButton4.isChecked() == true) {
                if (Val4Int < 0) {
                    String ResStrig = "Puros positivos";
                    textView1.setText(ResStrig);
                } else if (Val4Int > 999) {

                    String ResStrig = "numeros de 3 dígitos máximo";
                    textView1.setText(ResStrig);
                } else {
                    Result = Val4Int * Val4Int * (3.1416);

                    String ResStrig = String.valueOf(Result);

                    textView1.setText(ResStrig);
                }

            } else if (radioButton5.isChecked() == true) {
                if (Val3Int < 0) {
                    String ResStrig = "Puros positivos";
                    textView1.setText(ResStrig);
                } else if (Val3Int > 999) {

                    String ResStrig = "numeros de 3 dígitos máximo";
                    textView1.setText(ResStrig);
                } else {
                    Result = Val3Int * Val3Int;

                    String ResStrig = String.valueOf(Result);

                    textView1.setText(ResStrig);
                }

            } else if (radioButton6.isChecked() == true) {
                if (Val1Int < 0 || Val2Int < 0) {
                    String ResStrig = "Puros positivos";
                    textView1.setText(ResStrig);
                } else if (Val1Int > 999 || Val2Int > 999) {

                    String ResStrig = "numeros de 3 dígitos máximo";
                    textView1.setText(ResStrig);

                } else {
                    Result = Val1Int * Val2Int / (2);

                    String ResStrig = String.valueOf(Result);

                    textView1.setText(ResStrig);
                }
            } else {
                textView1.setText("Selecciona una figura");
            }
        }


    }

    public void Quitar(View view)
    {
        editText1.setText("0");
        editText2.setText("0");
        editText3.setText("0");
        editText4.setText("0");

        String ResStrig = "";

        textView1.setText(ResStrig);

    }

}
